#include<stdio.h>
#include<stdlib.h>
int main()
{
    FILE *fptr;
   fptr = fopen("banking.txt","a");

   if(fptr == NULL)
   {
      printf("Error!");
      exit(1);
   }


printf("1.create an account\n");
printf("2.cheack balance\n");
printf("5.Search account\n");
printf("3.deposite\n");
printf("4.withdraw\n");



printf("\n\n *Choice your number: ");
int a;
scanf("%d",&a);
if(a==1){
        char q[20];
        printf("your name: \n");

  scanf("%s",&q,sizeof(q),stdin);
  printf("your name is %s: ",q,sizeof(q),stdin);
int n;
printf("\nyour account number: \n");
scanf("%d",&n);
printf("your account number: %d ",n);

printf("\n\n\ncreate successfully: \n\n\n");

fprintf(fptr,"\n the name:%s \n",q);
    fprintf(fptr,"\n account number :%d",n);
}

    if(a==2){
        printf("balance cheack: ");
        FILE *fptr;
        fptr = fopen("banking.txt","r");
        char sl[150];
        while(!feof (fptr)){
            fgets(sl,150,fptr);
            puts(sl);
        }
        fclose(fptr);
    }

if(a==5){
    printf("search: ");
    char q[255];





    int acc;
    FILE *fptr;
        fptr = fopen("banking.txt","r");
        for(int i=0;i<1000;i++){
    fscanf(fptr,"%s",q);
    acc=atoi(q);
    if(acc==3456){
        fgets(q,255,(FILE*)fptr) ;
    printf("%s",q);
    break;
         }
        }
}


else
{

    printf("nafiz mollah");
}
return 0;
}
